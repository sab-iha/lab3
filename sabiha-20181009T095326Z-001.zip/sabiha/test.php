<?php
echo "Hello PHP";
$a=print("Hello PHP <br/>");
echo "<br/>";
echo $a;
$a = 10;
$b = "dd"; 

$array=['1','2','3'];
$array2=array('1','2','3');
$array=['name'=>'rainy','id'=>'2','email'=>'3'];
print_r($array);
for($i=0;$i<9;$i++)
{
echo $array['name'];echo "<br/>";
}

?>